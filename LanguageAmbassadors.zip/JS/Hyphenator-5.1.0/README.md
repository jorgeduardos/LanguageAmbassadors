# Hyphenator.js

This repository replaces https://code.google.com/p/hyphenator/

Please see the projects page on http://mnater.github.io/Hyphenator/ for instructions and further reading.